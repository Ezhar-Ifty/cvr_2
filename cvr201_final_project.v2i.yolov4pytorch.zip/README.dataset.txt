# cvr201_final_project > 2024-07-02 2:07pm
https://universe.roboflow.com/ifty/cvr201_final_project

Provided by a Roboflow user
License: CC BY 4.0

